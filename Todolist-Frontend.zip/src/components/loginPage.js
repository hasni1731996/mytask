import React from 'react'
import {Container, Col, Form, FormGroup, Label, Input, Button} from 'reactstrap';
import axios from 'axios';

class loginPage extends React.Component {
    constructor() {
        super();
        this.state = {
            username: '',
            password: '',
            errors: ''
        }
    }

    handleChange = event => {
        this.setState({[event.target.name]: event.target.value})
    };
    handleSubmit = event => {
        event.preventDefault();
        if (this.state.username === '') {
            this.setState({errors: 'Please Provide Username'});
        }
        else if(this.state.password === ''){
            this.setState({errors: 'Please Provide Password'});
        }
        else {
            const url = "http://127.0.0.1:8000/api-token-auth/";
            const data = {username: this.state.username, password: this.state.password};
            axios.post(url, data)
                .then(res => {
                    if (res.data.token) {
                        console.log('token here', res.data.token);
                        localStorage.setItem('token', res.data.token);
                        this.props.history.push('/dashboard');
                    }
                }).catch(res => {
                console.log('Error');
                this.setState({errors: 'Invalid Credentials'})
            })
        }
    };

    render() {
        return (
            <Container className="App">
                <h2>Sign In</h2>
                <Form className="form" onSubmit={this.handleSubmit}>
                    <Col>
                        <FormGroup>
                            <Label>Username</Label>
                            <Input
                                onChange={this.handleChange}
                                type="text"
                                name="username"
                                id="exampleEmail"
                                placeholder="hassan"
                            />
                        </FormGroup>
                    </Col>
                    <Col>
                        <FormGroup>
                            <Label for="examplePassword">Password</Label>
                            <Input
                                onChange={this.handleChange}
                                type="password"
                                name="password"
                                id="examplePassword"
                                placeholder="********"
                            />
                        </FormGroup>
                    </Col>
                    {this.state.errors ? <h3 className="alert alert-danger">{this.state.errors}</h3> : ''}
                    <Button type="submit" color="primary">Submit</Button>
                </Form>
            </Container>
        );
    }
}

export default loginPage