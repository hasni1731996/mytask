import React from 'react'
import {
    Navbar,
    NavbarBrand,
    Modal,
    ModalHeader,
    ModalBody,
    ModalFooter,
    Button,
    NavbarToggler,
    Collapse, Form, FormGroup, Label, Input, Col, Table
} from 'reactstrap';
import axios from "axios";

class dashboardPage extends React.Component {
    constructor() {
        super();
        this.state = {
            isOpen: false,
            modalOpen: false,
            modalUpdateOpen: false,
            itemname: '',
            taskname: '',
            taskid: '',
            errors: '',
            results: []
        }
    }

    getItems() {
        const url = "http://127.0.0.1:8000/tasks/";
        axios.get(url, {
            headers: {
                'Content-Type': 'application/json',
                "Authorization": "Token " + localStorage.getItem('token')
            }
        })
            .then(res => {
                if (res.data.results) {
                    this.setState({results: res.data.results})
                }
            }).catch(res => {
            console.log('Error');
            this.setState({errors: 'Error Performing your action'})
        })

    }

    updateItem(id, taskname) {
        this.setState({taskname: taskname, modalUpdateOpen: true, taskid: id});

    }

    handleUpdateSubmit = event => {
        event.preventDefault();
        // console.log('handle update method calling');
        const url = "http://127.0.0.1:8000/tasks/update/" + this.state.taskid;
        const data = {taskname: this.state.taskname};
        axios.put(url, data, {
            headers: {
                'Content-Type': 'application/json',
                "Authorization": "Token " + localStorage.getItem('token')
            }
        })
            .then(res => {
                if (res.data.detail) {
                    this.setState({modalUpdateOpen: false});
                    this.getItems();
                }
            }).catch(res => {
            console.log('Error');
            this.setState({errors: 'Eror Performing your action'})
        })
    };

    componentDidMount() {
        this.getItems();

    }

    handleChange = event => {
        this.setState({[event.target.name]: event.target.value})
    };

    handleUpdateChange = event => {
        this.setState({[event.target.name]: event.target.value})
    };
    handleSubmit = event => {
        event.preventDefault();
        const url = "http://127.0.0.1:8000/tasks/";
        const data = {taskname: this.state.itemname};
        axios.post(url, data, {
            headers: {
                'Content-Type': 'application/json',
                "Authorization": "Token " + localStorage.getItem('token')
            }
        })
            .then(res => {
                if (res.data.detail) {
                    this.getItems();
                    this.setState({modalOpen: false})
                    // this.props.history.push('/dashboard');
                }
            }).catch(res => {
            console.log('Error');
            this.setState({errors: 'Eror Performing your action'})
        })
    };

    toggle() {
        this.setState({isOpen: !this.state.isOpen})

    }

    modalHandler() {
        this.setState({modalOpen: !this.state.modalOpen})
    }

    modalUpdateHandler() {
        this.setState({modalUpdateOpen: !this.state.modalUpdateOpen})
    }

    render() {

        return (
            <div>
                <Navbar color="light" light expand="md">
                    <NavbarBrand href="/dashboard">To-Do List</NavbarBrand>
                    <NavbarToggler onClick={this.toggle.bind(this)}/>
                    <Collapse isOpen={this.state.isOpen} navbar>
                        <Button color="primary" onClick={() => this.setState({modalOpen: true})}>Add Item</Button>{' '}
                    </Collapse>
                </Navbar>

                {this.state.modalOpen === true ?
                    // header code for add item
                    <Modal isOpen={this.state.modalOpen}>
                        <ModalHeader toggle={this.modalHandler.bind(this)}>Add Item</ModalHeader>
                        <Form className="form" onSubmit={this.handleSubmit}>
                            <ModalBody>
                                <Col>
                                    <FormGroup>
                                        <Label>Item Name</Label>
                                        <Input
                                            onChange={this.handleChange}
                                            type="text"
                                            name="itemname"
                                            id="itemname"
                                            placeholder="item here"
                                        />
                                    </FormGroup>
                                </Col>
                            </ModalBody>
                            <ModalFooter>
                                <Button color="primary" type="submit">Submit</Button>{' '}
                                <Button color="secondary" onClick={this.modalHandler.bind(this)}>Cancel</Button>
                            </ModalFooter>
                        </Form>
                    </Modal> : ''
                    // ends here
                }

                {
                    this.state.taskname ?
                        // update modal
                        <Modal isOpen={this.state.modalUpdateOpen}>
                            <ModalHeader toggle={this.modalUpdateHandler.bind(this)}>Edit Item</ModalHeader>
                            <Form className="form" onSubmit={this.handleUpdateSubmit}>
                                <ModalBody>
                                    <Col>
                                        <FormGroup>
                                            <Label>Item Name</Label>
                                            <Input
                                                onChange={this.handleUpdateChange}
                                                type="text"
                                                value={this.state.taskname}
                                                name="taskname"
                                                id="taskname"
                                                placeholder="item here"
                                            />
                                        </FormGroup>
                                    </Col>
                                </ModalBody>
                                <ModalFooter>
                                    <Button color="primary" type="submit">Submit</Button>{' '}
                                    <Button color="secondary"
                                            onClick={this.modalUpdateHandler.bind(this)}>Cancel</Button>
                                </ModalFooter>
                            </Form>
                        </Modal> : ''
                    // ends here
                }
                <Table>
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    {
                        this.state.results.map(res => <tr key={res.id}>
                            <th>{res.id}</th>
                            <td>{res.taskname}</td>
                            <td><Button color="primary" type="button"
                                        onClick={this.updateItem.bind(this, res.id, res.taskname)}>Edit</Button>{' '}</td>

                        </tr>)
                    }
                    </tbody>
                </Table>
            </div>
        );
    }
}

export default dashboardPage;