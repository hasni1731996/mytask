import React, {Fragment} from 'react';
import ReactDOM from 'react-dom';
import * as serviceWorker from './serviceWorker';
import 'bootstrap/dist/css/bootstrap.min.css';
import {BrowserRouter, Route, Switch, Redirect} from 'react-router-dom';
import loginPage from './components/loginPage'
import dashboardPage from './components/dashboardPage'

//middleware

class checkStatus extends React.Component {
    render() {
        if (localStorage.getItem('token')) {
            return (
                <Fragment>

                    <Route path="/dashboard" exact component={dashboardPage}/>
                    <Route exact path="/" render={() => <Redirect to="/dashboard"/>}/>
                </Fragment>
            )
        } else {
            return (
                <Fragment>
                    <Route path="/" exact component={loginPage}/>
                    <Redirect to="/"/>
                </Fragment>
            )
        }
    }
}

ReactDOM.render(
    <BrowserRouter>
        <Switch>
            <Route path="/" exact component={checkStatus}/>
            <Route path="/:someParam" component={checkStatus}/>
        </Switch>
    </BrowserRouter>, document.querySelector('#root')
);
serviceWorker.unregister();
