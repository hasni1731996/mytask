from django.urls import path

from .views import *

urlpatterns = [
    path('tasks/', TaskView.as_view(), name='task'),
    path('tasks/update/<int:pk>', TaskUpdateView.as_view(), name='task_update'),
]
