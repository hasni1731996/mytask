from rest_framework import status
from rest_framework.views import APIView
from .serializers import *
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response


class TaskView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        res = Tasks.objects.filter(user__username=request.user.username)
        serializer = Task_Serializer(res, many=True)
        return Response({'results':serializer.data}, status=status.HTTP_200_OK)

    def post(self, request, *args, **kwargs):
        try:
            serializer = Task_Serializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            serializer.save(user=request.user)
            return Response({'detail':'task added successfully'}, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({'error':'Error performing your action'}, status=status.HTTP_400_BAD_REQUEST)


class TaskUpdateView(APIView):
    permission_classes = [IsAuthenticated]

    def put(self, request, *args, **kwargs):
        try:
            id = kwargs.get('pk', None)
            # print('id here..', id)
            task_id = Tasks.objects.get(id=id)
            serializer = Task_Serializer(task_id, data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({'detail':serializer.data}, status=status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            print('exception here..', str(e))
            return Response({'detail': 'Error performing your action'}, status=status.HTTP_400_BAD_REQUEST)